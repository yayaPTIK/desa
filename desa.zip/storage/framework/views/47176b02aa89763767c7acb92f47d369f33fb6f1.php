
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('tables/dataTables.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('alert/sweetalert2.css')); ?>"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <div class="row">
                <div class="col-md-6">
                    <h3>Data Domisili</h3>
                </div>
                <div class="col-md-6 d-flex justify-content-end ">
                    <a href="" title="Ajukan Domisili Orang lain" class="btn btn-info">
                        Ajukan
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped w-100 table-responsive" id="myTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Jenis Kelamin</th>
                        <th>Tempat Lahir</th>
                        <th>Tanggal Lahir</th>
                        <th>Agama</th>
                        <th>Pekerjaan</th>
                        <th>Warga Negara</th>
                        <th>status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->jenis_kelamin); ?></td>
                        <td><?php echo e($item->tempat); ?></td>
                        <td><?php echo e($item->tanggal); ?></td>
                        <td><?php echo e($item->agama); ?></td>
                        <td><?php echo e($item->pekerjaan); ?></td>
                        <td><?php echo e($item->negara); ?></td>
                        <td>
                            <?php if($item->status == 1): ?>
                                <button class="btn btn-sm btn-success">ACC</button>
                            <?php else: ?> 
                                <a href="<?php echo e(route('domisilis.edit', $item->id)); ?>" class="btn btn-sm btn-danger">Belum ACC</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="ft-box"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="<?php echo e(route('domisilis.show', $item->id)); ?>">Lihat Detail</a>
                                    <a class="dropdown-item"
                                            onclick="event.preventDefault(); document.getElementById('destroy-form').submit();">Hapus</a>
                                        <form id="destroy-form" action="<?php echo e(route('domisilis.destroy', $item->id)); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    <?php if($item->status == 0): ?>
                                        
                                        <a class="dropdown-item"
                                            onclick="event.preventDefault(); document.getElementById('destroy-form').submit();">Hapus</a>
                                        <form id="destroy-form" action="<?php echo e(route('domisilis.destroy', $item->id)); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('tables/dataTables.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('alert/sweetalert2.js')); ?>"></script>
    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/domisili/index.blade.php ENDPATH**/ ?>
 <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true"
     data-img="<?php echo e(asset('backend/theme-assets/images/backgrounds/02.jpg')); ?>">
     <div class="navbar-header">
         <ul class="nav navbar-nav flex-row">
             <li class="nav-item mr-auto">
                 <a class="navbar-brand" href="index.html"><img class="brand-logo" alt="Chameleon admin logo"
                         src="<?php echo e(asset('backend/theme-assets/images/logo/logo.png')); ?>" />
                     <h3 class="brand-text">SISUDE</h3>
                 </a>
             </li>
             <li class="nav-item d-md-none">
                 <a class="nav-link close-navbar"><i class="ft-x"></i></a>
             </li>
         </ul>
     </div>
     <div class="main-menu-content">
         <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
             <li class=" nav-item <?php echo e(Request::is('home') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('home')); ?>"><i class="ft-home"></i><span class="menu-title"
                         data-i18n="">Dashboard</span></a>
             </li>
             
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
             <li class="nav-item <?php echo e(Request::is('user*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('user.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                         data-i18n="">Penduduk</span></a>
             </li>
            <li class="nav-item <?php echo e(Request::is('kk*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('kk.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">Kartu Keluarga</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::is('sktms*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('sktms.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">SKTM</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::is('domisilis*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('domisilis.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">Domisili</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::is('kelahirans*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('kelahirans.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">Kelahiran</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::is('kematians*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('kematians.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">Kematian</span></a>
            </li>

             <li class="nav-item <?php echo e(Request::is('dusun*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dusun.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">Dusun</span></a>
            </li>
             <li class="nav-item <?php echo e(Request::is('kades*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('kades.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                        data-i18n="">Kepala Desa</span></a>
            </li>
             <?php endif; ?>

             

             
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user')): ?>
             <li class="nav-item <?php echo e(Request::is('sktm*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('sktm.index')); ?>"><i class="ft-file"></i><span class="menu-title"
                         data-i18n="">SKTM</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('kartu*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('kartu.index')); ?>"><i class="ft-layers"></i><span class="menu-title"
                         data-i18n="">Kartu
                         Keluarga</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('domisili*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('domisili.index')); ?>"><i class="ft-box"></i><span class="menu-title"
                         data-i18n="">Domisili</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('kelahiran*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('kelahiran.index')); ?>"><i class="ft-box"></i><span class="menu-title"
                         data-i18n="">Kelahiran</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('Kematian*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('Kematian.index')); ?>"><i class="ft-box"></i><span class="menu-title"
                         data-i18n="">Kematian</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('ktp*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('ktp.index')); ?>"><i class="ft-bold"></i><span class="menu-title"
                         data-i18n="">KTP</span></a>
             </li>
             <?php endif; ?>
             
         </ul>
     </div>
     <div class="navigation-background"></div>
 </div>
<?php /**PATH F:\www\desa\resources\views/layouts/partials/side.blade.php ENDPATH**/ ?>
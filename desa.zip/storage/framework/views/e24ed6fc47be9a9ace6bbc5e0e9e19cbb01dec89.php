
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <h3>User</h3>
        </div>
        <div class="card-body">
            <table class="table table-striped w-100 table-responsive-sm">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($a->name); ?></td>
                            <td><?php echo e($a->name); ?></td>
                            <td><?php echo e($a->name); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="ft-box"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                    <tr>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                        <td>contoh</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\desa\resources\views/admin/warga.blade.php ENDPATH**/ ?>
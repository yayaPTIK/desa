

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('tables/dataTables.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('alert/sweetalert2.css')); ?>"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <div class="row">
                <div class="col-md-6">
                    <h3>Data Kematian</h3>
                </div>
                <div class="col-md-6 d-flex justify-content-end ">
                    <a href="<?php echo e(route('kematians.create')); ?>" title="tambah data" class="btn btn-info">
                        <em class="ft-plus"></em>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped w-100 table-responsive-sm" id="myTable">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Tempat, Tanggal Lahir</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($a->nama2); ?></td>
                            <td><?php echo e($a->alamat_ktp); ?></td>
                            <td><?php echo e($a->tempat); ?>,<?php echo e($a->tanggal); ?></td>
                            <td>
                                <?php if($a->status == 1): ?>
                                    <button class="btn btn-sm btn-success">ACC</button>
                                <?php else: ?> 
                                    <button class="btn btn-sm btn-danger">Belum ACC</button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="ft-box"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="<?php echo e(route('kematians.edit', $a->id)); ?>">Edit</a>
                                        <a class="dropdown-item" href="<?php echo e(route('kematians.show', $a->id)); ?>">Lihat Detail</a>
                                        <a class="dropdown-item"
                                            onclick="event.preventDefault(); document.getElementById('destroy-form').submit();">Hapus</a>
                                        <form id="destroy-form" action="<?php echo e(route('kematians.destroy', $a->id)); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('tables/dataTables.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('alert/sweetalert2.js')); ?>"></script>
    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/kematian/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            <h3>Input Data Warga</h3>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <!-- col left -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Nama</label>
                            <input type="text" class="form-control" autofocus required>
                        </div>
                        <div class="form-group">
                            <label for="">NIK</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Alamat</label>
                            <div class="row">
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="dusun" placeholder="Dusun" required>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="rt/rw" placeholder="RT/RW" required>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="dusun" placeholder="Dusun" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Jenis Kelamin</label>
                            <select name="jk" id="jk" class="form-control">
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Tempat Lahir</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal Lahir</label>
                            <input type="date" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Agama</label>
                            <select name="agama" id="agama" class="form-control">
                                <option value="Islam">Islam</option>
                                <option value="Kristen">Kristen</option>
                                <option value="Hindu">Hindu</option>
                                <option value="Budha">Budha</option>
                                <option value="Katolik">Katolik</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                    </div>

                    <!-- col right -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Status</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Status Keadaan</label>
                            <select name="keadaan" id="keadaan" class="form-control">
                                <option value="Kematian">Kematian</option>
                                <option value="Kelahiran">Kelahiran</option>
                                <option value="Pindah">Pindah</option>
                                <option value="Datang">Datang</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">KK Status</label>
                            <select name="kkStatus" id="kkStatus" class="form-control">
                                <option value="0">False</option>
                                <option value="1">True</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Domisili</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Pekerjaan</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="text" class="form-control" required>
                        </div>
                    </div>

                    <!-- button -->
                    <div class="row">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary ml-1" style="width:100%">Simpan</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\desa\resources\views/admin/create.blade.php ENDPATH**/ ?>
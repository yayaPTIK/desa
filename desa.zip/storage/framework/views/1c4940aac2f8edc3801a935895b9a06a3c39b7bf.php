
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('tables/dataTables.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('alert/sweetalert2.css')); ?>"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <div class="row">
                <div class="col-md-6">
                    <h3>Data SKTM</h3>
                </div>
                <div class="col-md-6 d-flex justify-content-end ">
                    <a href="<?php echo e(route('sktm.create')); ?>" title="tambah data" class="btn btn-info">
                        <em class="ft-plus"></em>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped w-100 table-responsive-sm" id="myTable">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Nomor Surat</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($a->nomor); ?></td>
                            <td><?php echo e($a->alamatOrtu); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="ft-box"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        
                                        <a class="dropdown-item" href="<?php echo e(route('sktm.show', $a->id)); ?>">Lihat Detail</a>
                                        
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('tables/dataTables.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('alert/sweetalert2.js')); ?>"></script>
    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\desa\resources\views/admin/sktm/index.blade.php ENDPATH**/ ?>
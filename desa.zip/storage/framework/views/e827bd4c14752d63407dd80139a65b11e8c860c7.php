
<?php $__env->startSection('content'); ?>
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            
            <div class="col-md-12 d-flex justify-content-end ">
                <a href="<?php echo e(route('addkk',$data->id)); ?>" title="tambah data" class="btn btn-info">
                    <em class="ft-plus"></em>
                </a>
            </div>
            <div class="col-md-12">
                <h1 class="text-center">Kartu Keluarga</h1>
                <h4 class="text-center">No. <?php echo e($data->nomor); ?></h4>
            </div>            
            <table class="w-100">
                <tr>
                    <td class="text-left">
                        Nama Kepala Keluarga      : <?php echo e($data->user_id); ?> <br>
                        
                        RT/RW                : <?php echo e($data->rtrw); ?> <br>
                        Desa                 : <?php echo e($data->desa); ?> 
                    </td>
                    <td class="text-right">
                        Kecamatan            : <?php echo e($data->kecamatan); ?> <br>
                        Kabupaten            : <?php echo e($data->kabupaten); ?> <br>
                        Provinsi             : <?php echo e($data->provinsi); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover table-responsive">
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap</th>
                            <th>NIK</th>
                            <th>Jenis Kelamin</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Agama</th>
                            <th>Pekerjaan</th>
                            <th>Action</th>
                        </tr>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $dataUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->nik); ?></td>
                                <td><?php echo e($item->jenis_kelamin); ?></td>
                                <td><?php echo e($item->tempat_lahir); ?></td>
                                <td><?php echo e($item->tanggal_lahir); ?></td>
                                <td><?php echo e($item->agama); ?></td>
                                <td><?php echo e($item->pekerjaan); ?></td>
                                <td>
                                    <a class="" onclick="event.preventDefault(); document.getElementById('destroy-form').submit();">Hapus</a>
                                        <form id="destroy-form" action="<?php echo e(route('addkk.destroy', $item->id)); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                          </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>

        <div class="card-footer">
            <div class="row">
                <div class="col-md-12">
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/kk/detail.blade.php ENDPATH**/ ?>
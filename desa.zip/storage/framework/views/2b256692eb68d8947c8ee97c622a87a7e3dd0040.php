 <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true"
     data-img="<?php echo e(asset('backend/theme-assets/images/backgrounds/02.jpg')); ?>">
     <div class="navbar-header">
         <ul class="nav navbar-nav flex-row">
             <li class="nav-item mr-auto">
                 <a class="navbar-brand" href="index.html"><img class="brand-logo" alt="Chameleon admin logo"
                         src="<?php echo e(asset('backend/theme-assets/images/logo/logo.png')); ?>" />
                     <h3 class="brand-text">SISUDE</h3>
                 </a>
             </li>
             <li class="nav-item d-md-none">
                 <a class="nav-link close-navbar"><i class="ft-x"></i></a>
             </li>
         </ul>
     </div>
     <div class="main-menu-content">
         <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
             <li class=" nav-item <?php echo e(Request::is('home') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('home')); ?>"><i class="ft-home"></i><span class="menu-title"
                         data-i18n="">Dashboard</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('user*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('user.index')); ?>"><i class="ft-pie-chart"></i><span class="menu-title"
                         data-i18n="">Penduduk</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('sktm*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('sktm.index')); ?>"><i class="ft-file"></i><span class="menu-title"
                         data-i18n="">SKTM</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('kk*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('kk.index')); ?>"><i class="ft-layers"></i><span class="menu-title"
                         data-i18n="">Kartu
                         Keluarga</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('domisili*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('domisili.index')); ?>"><i class="ft-box"></i><span class="menu-title"
                         data-i18n="">Domisili</span></a>
             </li>
             <li class="nav-item <?php echo e(Request::is('ktp*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('ktp.index')); ?>"><i class="ft-bold"></i><span class="menu-title"
                         data-i18n="">KTP</span></a>
             </li>
         </ul>
     </div>
     <div class="navigation-background"></div>
 </div>
<?php /**PATH D:\www\desa\resources\views/layouts/partials/side.blade.php ENDPATH**/ ?>
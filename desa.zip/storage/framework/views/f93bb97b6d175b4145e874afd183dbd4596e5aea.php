
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('tables/dataTables.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('alert/sweetalert2.css')); ?>"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <div class="row">
                <div class="col-md-6">
                    <h3>Data KTP</h3>
                </div>
                <div class="col-md-6 d-flex justify-content-end ">
                    <a href="<?php echo e(route('sktm.create')); ?>" title="tambah data" class="btn btn-info">
                        <em class="ft-plus"></em>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped w-100 table-responsive-sm" id="myTable">
            </table>
        </div>
    </div>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('tables/dataTables.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('alert/sweetalert2.js')); ?>"></script>
    <?php if(session('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                button: "OK",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\desa\resources\views/admin/ktp/index.blade.php ENDPATH**/ ?>
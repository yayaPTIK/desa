
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <div class="row">
                <div class="col-md-6">
                    <h3>Surat Keterangan Tidak Mampu</h3>
                </div>
                <div class="col-md-6 d-flex justify-content-end ">
                    <button href="<?php echo e(route('sktm.create')); ?>" title="Print" class="btn btn-info" onclick="printDiv('show')">
                        <em class="la la-print"></em>
                    </button>
                    <script type="text/javascript">
                        function printDiv(show) {
                            var printContents = document.getElementById(show).innerHTML;
                            var originalContents = document.body.innerHTML;
                            document.body.innerHTML = "<html><head><title></title></head><body>" + printContents + "</body>";
                            window.print();
                            document.body.innerHTML = originalContents;
                        }
                    </script>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="" id="show">
                <header class="col-md-10 m-auto">
                    <div class="row mt-5" style="border-bottom: 3px solid black">

                        <div class="col-md-12 text-center">
                            <h3 class="col-sm-12 fs-12px">
                                PEMERINTAH KABUPATEN KUNINGAN <br />
                                KECAMATAN GARAWANGI <br />
                                DESA KERTAUNGGARAN
                            </h3>
                            <span>Jalan Muhammad Yamin No.14 Kedungarum, Kuningan
                                Telp.(0232)8882858</span>
                        </div>
                    </div>
                </header>
                
                <section class="col-md-10 m-auto">
                    <div class="row text-center mt-2">
                        <div class="col-md-8 offset-2">
                            <span><strong><u>SURAT KETERANGAN TIDAK MAMPU <br> </u></strong></span>
                            <span>Nomor : 001/LBN/I/2022</span>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-10 m-auto">
                            <p>Yang bertanda tangan dibawah ini Kepala Desa Kertaunggaran menerangkan bahwa :</p>
                            <table class="ml-5" cellpadding="3" cellspacing="3">
                                <tr>
                                    <td>Nama</td>
                                    <td> : </td>

                                    <td><?php echo e($data->nama); ?></td>
                                </tr>
                                <tr>
                                    <td>Jenis Kelamin</td>
                                    <td> : </td>

                                    <td><?php echo e($data->jk); ?></td>
                                </tr>
                                <tr>
                                    <td>Tempat, Tanggal Lahir</td>
                                    <td> : </td>

                                    <td><?php echo e($data->ttl); ?></td>
                                </tr>
                                <tr>
                                    <td>Alamat</td>
                                    <td> : </td>

                                    <td><?php echo e($data->alamatOrtu); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Orang Tua</td>
                                    <td> : </td>

                                    <td><?php echo e($data->namaOrtu); ?></td>
                                </tr>
                            </table>
                            <p class="mt-3">Bahwa oknum tersebut di atas adalah benar-benar keluarga tidak mampu.</p>
                            <p class="mt-3">Demikian surat keterangan ini kami buat dengan sebenarnya untuk dipergunakan
                                semestinya.</p>
                        </div>
                    </div>
                </section>
                <section class="mt-5">
                    <div class="col-md-4 ml-auto text-left">
                        Kertaunggaran, <?php echo e(date('d F Y')); ?> <br>
                        Kepala Desa Kertaunggaran
                        <?php if($data->status == 1): ?>
                            <br />
                            <img src="" alt="" style="width: 200px">
                            <p class="mb-5">
                            </p>
                        <?php else: ?>
                            <br />
                            <span class="badge badge-danger">Diperoses</span>
                            <p class="mt-5">
                                Nama Kepala Desa
                            </p>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/sktm/show.blade.php ENDPATH**/ ?>
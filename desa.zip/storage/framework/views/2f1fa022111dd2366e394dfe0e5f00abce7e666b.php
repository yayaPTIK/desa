
<?php $__env->startSection('content'); ?>
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            <h3>Laporan Kematian</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('kematians.update', $data->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Nama Yang Meninggal</label>
                            <input type="text" class="form-control" name="namaMeninggal" placeholder="Nama Yang Meninggal" required value="<?php echo e($data->nama2); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="">Tempat Lahir</label>
                            <input type="text" class="form-control" name="tempat" placeholder="Tempat Lahir Pelapor" required value="<?php echo e($data->tempat); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="tanggal" placeholder="Tanggal Lahir" required value="<?php echo e($data->tanggal); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Agama</label>
                            <input type="text" class="form-control" name="agamaMeninggal" placeholder="Agama" required value="<?php echo e($data->agama2); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Nama Ayah</label>
                            <input type="text" class="form-control" name="namaAyah" placeholder="Nama Ayah" required value="<?php echo e($data->nama_ayah); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Nama Ibu</label>
                            <input type="text" class="form-control" name="namaIbu" placeholder="Nama Ibu" required value="<?php echo e($data->nama_ibu); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12"><h5 class="text-center">Keterangan Lainnya</h5></div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Alamat Sesuai KTP</label>
                            <input type="text" class="form-control" name="alamatMeninggal" placeholder="Alamat Sesuai KTP" required value="<?php echo e($data->alamat_ktp); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Hari</label>
                            <input type="text" class="form-control" name="hariMeninggal" placeholder="Hari Meninggal" required value="<?php echo e($data->Hari); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal Meninggal</label>
                            <input type="date" class="form-control" name="tanggalMeninggal" placeholder="Tanggal Meninggal" required value="<?php echo e($data->tanggal_meninggal); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Tempat Meninggal</label>
                            <input type="text" class="form-control" name="tempatMeninggal" placeholder="Tempat Meninggal" required value="<?php echo e($data->tempat_meninggal); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Setujui Pengaduan / Laporan ? </label>
                            <select name="status" id="status" class="form-control" required>
                                <option value="1">Ya</option>
                                <option value="0">Tidak</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary w-100">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/kematian/edit.blade.php ENDPATH**/ ?>
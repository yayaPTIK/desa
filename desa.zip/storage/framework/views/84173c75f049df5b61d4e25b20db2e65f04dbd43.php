
<?php $__env->startSection('content'); ?>
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            <h3>Profile</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- left -->
                <div class="col-md-4">
                    <table class="table table-responsive table-active" width="100%">
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td>Dusun <?php echo e($user->dusun); ?>, RT.<?php echo e($user->rt); ?> RW.<?php echo e($user->rw); ?></td>
                        </tr>
                        <tr>
                            <td>NIK</td>
                            <td>:</td>
                            <td><?php echo e($user->nik); ?></td>
                        </tr>
                        <tr>
                            <td>Tempat Lahir</td>
                            <td>:</td>
                            <td><?php echo e($user->tempat_lahir); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td>:</td>
                            <td><?php echo e($user->tanggal_lahir); ?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php echo e($user->jenis_kelamin); ?></td>
                        </tr>
                    </table>
                </div>

                <!-- mid -->
                <div class="col-md-4 m-auto">
                    <img src="<?php echo e(asset('uploads/avatar/'.$user->avatar)); ?>" class="img-thumbnail" alt="" style="width:100%">
                    <div class="form-group">
                    </div>
                </div>

                <!-- right -->
                <div class="col-md-4">
                     <table class="table table-responsive table-active" width="100%">
                        <tr>
                            <td>Agama</td>
                            <td>:</td>
                            <td><?php echo e($user->agama); ?></td>
                        </tr>
                        <tr>
                            <td>Status</td>
                            <td>:</td>
                            <td><?php echo e($user->status); ?></td>
                        </tr>
                        <tr>
                            <td>Keadaan</td>
                            <td>:</td>
                            <td><?php echo e($user->status_keadaan); ?></td>
                        </tr>
                        <tr>
                            <td>Domisili</td>
                            <td>:</td>
                            <td><?php echo e($user->domisili); ?></td>
                        </tr>
                        <tr>
                            <td>Status KK</td>
                            <td>:</td>
                            <td><?php echo e($user->kk_status); ?></td>
                        </tr>
                        <tr>
                            <td>Pekerjaan</td>
                            <td>:</td>
                            <td><?php echo e($user->pekerjaan); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="card-footer">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-warning" style="width:100%">Edit Semua</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\desa\resources\views/admin/penduduk/detail.blade.php ENDPATH**/ ?>
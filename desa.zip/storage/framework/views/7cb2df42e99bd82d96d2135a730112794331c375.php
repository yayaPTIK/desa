
<?php $__env->startSection('content'); ?>
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            <h3>Edit Kartu Keluarga</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('kk.update', $data->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Nomor KK</label>
                            <input type="text" class="form-control" name="nomor" placeholder="nomor" required value="<?php echo e($data->nomor); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Kepala Keluarga</label>
                            
                            <select name="kepala" id="kepala" required class="form-control">
                                <option value="">-- Pilih Kepala Keluarga --</option>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $data->user_id?"selected":""); ?>><?php echo e($item->nik); ?> - <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Alamat</label>
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="inputCity" class="form-label">RT/RW</label>
                                    <input type="text" class="form-control" name="rtrw" id="inputCity"
                                        placeholder="RT/RW" required value="<?php echo e($data->rtrw); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label for="inputState" class="form-label">Desa</label>
                                    <input type="text" class="form-control" name="desa" id="inputCity"
                                        placeholder="Desa" value="<?php echo e($data->desa); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Kecamatan</label>
                            <input type="text" class="form-control" placeholder="Kecamatan" name="kecamatan" required value="<?php echo e($data->kecamatan); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Kabupaten</label>
                            <input type="text" class="form-control" name="kabupaten" placeholder="Kabupaten" required value="<?php echo e($data->kabupaten); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Provinsi</label>
                            <input type="text" class="form-control" name="provinsi" placeholder="Provinsi" required value="<?php echo e($data->provinsi); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary w-100">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/kk/edit.blade.php ENDPATH**/ ?>
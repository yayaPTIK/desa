
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-head m-3">
            <div class="row">
                <div class="col-md-6">
                    <h3>Surat Keterangan Kelahiran</h3>
                </div>
                <div class="col-md-6 d-flex justify-content-end ">
                    <button href="<?php echo e(route('sktm.create')); ?>" title="Print" class="btn btn-info" onclick="printDiv('show')">
                        <em class="la la-print"></em>
                    </button>
                    <script type="text/javascript">
                        function printDiv(show) {
                            var printContents = document.getElementById(show).innerHTML;
                            var originalContents = document.body.innerHTML;
                            document.body.innerHTML = "<html><head><title></title></head><body>" + printContents + "</body>";
                            window.print();
                            document.body.innerHTML = originalContents;
                        }
                    </script>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="" id="show">
                <header class="col-md-10 m-auto">
                    <div class="row mt-5" style="border-bottom: 3px solid black">

                        <div class="col-md-12 text-center">
                            <h3 class="col-sm-12 fs-12px">
                                PEMERINTAH KABUPATEN KUNINGAN <br />
                                KECAMATAN GARAWANGI <br />
                                DESA KERTAUNGGARAN
                            </h3>
                            <span>Jalan Muhammad Yamin No.14 Kedungarum, Kuningan
                                Telp.(0232)8882858</span>
                        </div>
                    </div>
                </header>
                
                <section class="col-md-10 m-auto">
                    <div class="row text-center mt-2">
                        <div class="col-md-8 offset-2">
                            <span><strong><u>SURAT KETERANGAN KELAHIRAN <br> </u></strong></span>
                            <span>Nomor : <?php echo e($data->nomor); ?></span>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-10 m-auto">
                            <p>Yang bertanda tangan dibawah ini Kepala Desa Kertaunggaran menerangkan bahwa :</p>
                            <table class="ml-5" cellpadding="3" cellspacing="3">
                                <tr>
                                    <td>Nama</td>
                                    <td> : </td>

                                    <td><?php echo e($data->nama); ?></td>
                                </tr>
                                
                                <tr>
                                    <td>Tempat, Tanggal Lahir</td>
                                    <td> : </td>

                                    <td><?php echo e($data->tempat); ?>, <?php echo e($data->tanggal); ?></td>
                                </tr>
                            </table>

                            <p>Anak Dari : </p>
                            <table class="ml-5" cellpadding="3" cellspacing="3">
                                <tr>
                                    <td>Nama Ayah</td>
                                    <td> : </td>

                                    <td><?php echo e($data->nama_ayah); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Ibu</td>
                                    <td> : </td>

                                    <td><?php echo e($data->nama_ibu); ?></td>
                                </tr>
                                <tr>
                                    <td>Anak Ke-</td>
                                    <td> : </td>

                                    <td><?php echo e($data->anak); ?></td>
                                </tr>
                            </table>
                           
                            <p class="mt-3">Demikian surat keterangan kelahiran ini kami buat dengan sebenarnya untuk dipergunakan
                                semestinya.</p>
                        </div>
                    </div>
                </section>
                <section class="mt-5">
                    <div class="col-md-4 ml-auto text-left">
                        Kertaunggaran, <?php echo e($data->created_at->format('d F Y')); ?> <br>
                        Kepala Desa Kertaunggaran
                        <?php if($data->status == 1): ?>
                            <br />
                            <img src="<?php echo e(asset('uploads/kades/'.$kades->ttd)); ?>" class="" alt="<?php echo e($kades->ttd); ?>" style="width: 100px">
                            <p class="mb-5 ">
                                <?php echo e($kades->nama); ?>

                            </p>
                        <?php else: ?>
                            <br />
                            <span class="badge badge-danger">Diperoses</span>
                            <p class="mt-5">
                                Nama Kepala Desa
                            </p>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/user/kelahiran/detail.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            <h3>Tambah Anggota Kartu Keluarga</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('addkk.store', $data->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">ID KK</label>
                            <input type="text" class="form-control" name="id" required value="<?php echo e($data->id); ?>">
                        </div>
                        <div class="form-group">
                            <select name="user" id="user" class="form-control" required>
                                <option value="">-- Pilih Nama --</option>
                                <?php $__currentLoopData = $dataUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nik); ?> - <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary w-100">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\www\desa\resources\views/admin/kk/add.blade.php ENDPATH**/ ?>
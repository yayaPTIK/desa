@extends('layouts.apps')
@section('content')
    <div class="card col-md-12 m-auto">
        <div class="card-head mt-3 ml-2">
            <h3>Buat Surat Pengantar KTP</h3>
        </div>
        <div class="card-body">
            <form action="{{ route('ktp.store') }}" method="post">
                @csrf
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">NIK</label>
                            <input type="text" class="form-control" name="nik" placeholder="NIK" readonly
                                value="{{ Auth::user()->nik }}">
                        </div>
                        <div class="form-group">
                            <label for="">Provinsi</label>
                            <input type="text" class="form-control" name="provinsi" placeholder="Provinsi"
                                autofocus>
                        </div>
                        <div class="form-group">
                            <label for="">Kabupaten / Kota</label>
                            <input type="text" class="form-control" name="kabupaten" placeholder="Kabupaten / Kota"
                                autofocus>
                        </div>
                        <div class="form-group">
                            <label for="">Kecamatan</label>
                            <input type="text" class="form-control" name="kecamatan" placeholder="Kecamatan"
                                autofocus>
                        </div>
                        <div class="form-group">
                            <label for="">Kelurahan</label>
                            <input type="text" class="form-control" name="kelurahan" placeholder="Kelurahan"
                                autofocus>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Alamat</label>
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="inputCity" class="form-label">RT</label>
                                    <input type="text" class="form-control" name="rt" id="inputCity"
                                        placeholder="RT">
                                </div>
                                <div class="col-md-3">
                                    <label for="inputCity" class="form-label">RW</label>
                                    <input type="text" class="form-control" name="rw" id="inputCity"
                                        placeholder="RW">
                                </div>
                                <div class="col-md-6">
                                    <label for="inputState" class="form-label">Dusun</label>
                                    <input type="text" class="form-control" name="dusun" placeholder="Dusun" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" placeholder="Nama" readonly
                                value="{{ Auth::user()->name }}">
                        </div>
                        <div class="form-group">
                            <label for="jenis permohonan">Jenis Permohonan</label>
                            <select name="jPermohonan" id="jPermohonan" class="form-control" required>
                                <option value="pergantian">Pergantian</option>
                                <option value="baru">Buat Baru</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Nomor Kartu Keluarga</label>
                            <input type="text" class="form-control" name="noKK" placeholder="Nomor Kartu Keluarga">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary w-100">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection
